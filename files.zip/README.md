# Infraestructura 1 — VPN sitio a sitio entre dos FortiGate

## Propósito del laboratorio

Demostrar que dos sedes separadas por una red pública (ISP) pueden comunicarse de forma segura mediante una **VPN IPsec sitio a sitio** entre dos FortiGate, configurados **100 % por la interfaz gráfica (GUI)**, y comprobar que la comunicación entre el usuario y el servidor web **solo fluye mientras el túnel VPN está activo**.

### Objetivos

- Comunicar el equipo de usuario (sede 1) con el servidor web (sede 2) a través del enlace VPN.
- Comprobar que, sin túnel, no hay comunicación entre las dos redes privadas.
- Configurar redes, NAT y la VPN sitio a sitio entre los dos FortiGate.
- Publicar un servidor web con HTTPS y entregar un usuario en la VLAN 10 con DHCP y traceroute hacia el servidor.

## Topología

![Topología en GNS3](images/topologia-gns3.png)

```mermaid
graph TD
    ISP["ISP (R1)<br/>f0/0 10.50.50.2/30<br/>f1/0 192.168.100.2/30"]
    FG1["FortiGate-1"]
    FG2["FortiGate-2"]
    SW["Switch1<br/>VLAN 10"]
    PC["PC1 (usuario)<br/>DHCP"]
    SRV["Servidor Web HTTPS<br/>(Ubuntu)"]

    FG1 ---|"Port1 10.50.50.1/30"| ISP
    ISP ---|"Port1 192.168.100.1/30"| FG2
    FG1 -.-|"Túnel IPsec"| FG2
    FG1 ---|"Port10 (VLAN 10) 192.168.110.1"| SW
    SW --- PC
    FG2 ---|"Port10 10.50.52.1"| SRV
```

### Equipos

| Equipo | Rol | Plataforma |
|---|---|---|
| FortiGate-1 | Cortafuegos / extremo VPN de la sede de usuarios | FortiGate VM 7.0.9 (GNS3, QEMU) |
| FortiGate-2 | Cortafuegos / extremo VPN de la sede del servidor | FortiGate VM 7.0.9 (GNS3, QEMU) |
| R1 | ISP (simula internet con IP públicas) | Cisco c7200 (Dynamips) |
| Switch1 | Conmutación y VLAN 10 de usuarios | Switch Ethernet de GNS3 |
| PC1 | Usuario (DHCP, ping, traceroute) | VPCS |
| Servidor Web | Servidor HTTPS | Ubuntu Desktop 24 (VMware) |

## Plan de direccionamiento

| Segmento | Red | Dispositivo | Interfaz | Dirección |
|---|---|---|---|---|
| FortiGate-1 ↔ ISP | 10.50.50.0/30 | FortiGate-1 | Port1 | 10.50.50.1 |
| | | R1 | f0/0 | 10.50.50.2 |
| ISP ↔ FortiGate-2 | 192.168.100.0/30 | R1 | f1/0 | 192.168.100.2 |
| | | FortiGate-2 | Port1 | 192.168.100.1 |
| Usuarios (VLAN 10) | 192.168.110.0/24 | FortiGate-1 | Port10 (VLAN 10) | 192.168.110.1 (puerta de enlace y servidor DHCP) |
| | | PC1 | e0 | DHCP (192.168.110.2) |
| Servidor | 10.50.52.0/24 | FortiGate-2 | Port10 | 10.50.52.1 (puerta de enlace) |
| | | Servidor Web | ens33 | 10.50.52.10 |

### Conexiones físicas

| Extremo A | Extremo B |
|---|---|
| FortiGate-1 Port1 | R1 f0/0 |
| R1 f1/0 | FortiGate-2 Port1 |
| FortiGate-1 Port10 | Switch1 e0 (troncal, VLAN 10 etiquetada) |
| Switch1 e1 (acceso VLAN 10) | PC1 e0 |
| FortiGate-2 Port10 | Servidor Web (Ubuntu) |

> El ISP solo conoce sus redes conectadas. No tiene rutas hacia 192.168.110.0/24 ni 10.50.52.0/24, por eso la única vía entre usuario y servidor es el túnel.

## Configuración

### ISP (R1)

Script: [`scripts/isp-r1.cfg`](scripts/isp-r1.cfg)

### Switch1 (VLAN 10)

| Puerto | Modo | VLAN |
|---|---|---|
| e0 (hacia FortiGate-1 Port10) | Troncal (dot1q) | 10 etiquetada |
| e1 (hacia PC1) | Acceso | 10 |

### FortiGate-1 (GUI)

1. **Red > Interfaces**
   - `port1`: rol WAN, direccionamiento manual `10.50.50.1/255.255.255.252`.
   - Crear interfaz nueva tipo VLAN sobre `port10`: nombre `VLAN10`, ID 10, rol LAN, IP `192.168.110.1/255.255.255.0`, **servidor DHCP** activado.
2. **Red > Rutas estáticas**: destino `0.0.0.0/0`, puerta de enlace `10.50.50.2`, interfaz `port1`.
3. **VPN > Asistente de IPsec** (plantilla *Sitio a sitio*, dispositivo remoto FortiGate, sin NAT entre los extremos):
   - IP del par remoto: `192.168.100.1`, interfaz saliente `port1`.
   - Autenticación: clave precompartida.
   - Interfaz local `VLAN10`, subred local `192.168.110.0/24`, subred remota `10.50.52.0/24`.
4. **Política y objetos > Política de firewall**
   - `VLAN10 → port1` con **NAT activado** (salida a internet).
   - `VLAN10 → túnel` y `túnel → VLAN10` con **NAT desactivado** (las crea el asistente).

### FortiGate-2 (GUI)

1. **Red > Interfaces**
   - `port1`: rol WAN, `192.168.100.1/255.255.255.252`.
   - `port10`: rol LAN, `10.50.52.1/255.255.255.0`.
2. **Red > Rutas estáticas**: `0.0.0.0/0` por `192.168.100.2`, interfaz `port1`.
3. **VPN > Asistente de IPsec** (plantilla *Sitio a sitio*):
   - IP del par remoto: `10.50.50.1`, interfaz saliente `port1`, **misma clave precompartida**.
   - Interfaz local `port10`, subred local `10.50.52.0/24`, subred remota `192.168.110.0/24`.
4. **Política y objetos > Política de firewall**
   - `port10 → port1` con NAT activado.
   - `túnel → port10` y `port10 → túnel` con NAT desactivado (las crea el asistente), permitiendo HTTPS (443) y ICMP hacia el servidor.

### Parámetros de la VPN

| Parámetro | Valor |
|---|---|
| Tipo | IPsec sitio a sitio, basada en ruta |
| Fase 1 | IKEv2 (o IKEv1), AES-256, SHA-256, DH grupo 14 |
| Fase 2 | AES-256, SHA-256 |
| Selectores | 192.168.110.0/24 ↔ 10.50.52.0/24 |
| Autenticación | Clave precompartida |

### PC1 y Servidor Web

- PC1: [`scripts/pc1-vpcs.txt`](scripts/pc1-vpcs.txt)
- Servidor (red): [`scripts/servidor-netplan.yaml`](scripts/servidor-netplan.yaml)
- Servidor (HTTPS): [`scripts/servidor-https.sh`](scripts/servidor-https.sh)

## Pruebas y evidencias

| # | Prueba | Resultado esperado | Evidencia |
|---|---|---|---|
| 1 | PC1 obtiene IP por DHCP | 192.168.110.x/24, puerta de enlace 192.168.110.1 | `images/01-dhcp.png` |
| 2 | Estado del túnel en **Monitor > Monitor de IPsec** | Túnel activo en ambos FortiGate | `images/02-tunel-activo.png` |
| 3 | `ping` de PC1 al servidor (túnel activo) | Respuesta | `images/03-ping-ok.png` |
| 4 | `traceroute` de PC1 al servidor | Sin saltos del ISP (10.50.50.2 / 192.168.100.2) | `images/04-traceroute.png` |
| 5 | Acceso HTTPS `https://10.50.52.10` desde un cliente de la LAN de usuarios | Página cargada | `images/05-https.png` |
| 6 | Se desactiva el túnel y se repiten `ping` y HTTPS | Sin comunicación | `images/06-sin-vpn.png` |
| 7 | Se reactiva el túnel | La comunicación se restablece | `images/07-restablecido.png` |

## Estructura del repositorio

```
infraestructura-1/
├── README.md
├── scripts/
│   ├── isp-r1.cfg
│   ├── pc1-vpcs.txt
│   ├── servidor-netplan.yaml
│   └── servidor-https.sh
├── running-configs/
│   ├── fortigate-1.conf
│   ├── fortigate-2.conf
│   └── r1-running-config.txt
└── images/
```
