#!/bin/bash
# Servidor web con HTTPS (nginx + certificado autofirmado)
set -e
sudo apt update
sudo apt install -y nginx openssl

sudo mkdir -p /etc/nginx/ssl
sudo openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
  -keyout /etc/nginx/ssl/servidor.key \
  -out /etc/nginx/ssl/servidor.crt \
  -subj "/C=DO/O=Laboratorio/CN=10.50.52.10"

sudo tee /etc/nginx/sites-available/default > /dev/null << 'CONF'
server {
    listen 443 ssl default_server;
    ssl_certificate     /etc/nginx/ssl/servidor.crt;
    ssl_certificate_key /etc/nginx/ssl/servidor.key;
    root /var/www/html;
    index index.html;
}
CONF

echo "<h1>Servidor Web - Infraestructura 1 (HTTPS por VPN)</h1>" | sudo tee /var/www/html/index.html
sudo nginx -t && sudo systemctl restart nginx
