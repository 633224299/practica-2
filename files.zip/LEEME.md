# Running-configs

Coloca aquí las configuraciones finales exportadas:

- `fortigate-1.conf` y `fortigate-2.conf`: en la GUI, menú del usuario (arriba a la derecha) > **Configuración > Copia de seguridad**, destino "Equipo local".
- `r1-running-config.txt`: en R1, `show running-config`.
